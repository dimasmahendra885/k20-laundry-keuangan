<x-layouts.app>
    <div>
        <!-- Page Header -->
        <div class="mb-stack-lg flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
                <h2 class="text-[40px] font-bold text-primary leading-none">Pengaturan Aplikasi</h2>
                <p class="text-body-lg text-on-surface-variant mt-2">Kelola informasi toko dan pengaturan aplikasi lainnya.</p>
            </div>
        </div>

        @if (session()->has('success'))
            <div class="mb-6 p-4 bg-secondary/10 border border-secondary/20 text-secondary rounded-xl flex items-center gap-3">
                <span class="material-symbols-outlined">check_circle</span>
                <p class="text-label-md font-medium">{{ session('success') }}</p>
            </div>
        @endif

        <!-- Form Card -->
        <div class="bg-surface-container-lowest border border-outline-variant rounded-3xl shadow-lg overflow-hidden">
            <div class="p-8">
                <form action="{{ route('pengaturan.update') }}" method="POST" class="space-y-8">
                    @csrf
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="space-y-2">
                            <label class="text-label-md font-label-md text-on-surface-variant px-1">Nama Toko</label>
                            <input type="text" name="nama_toko" value="{{ old('nama_toko', $setting->nama_toko) }}" 
                                class="w-full bg-surface-container-low border border-outline-variant/30 rounded-xl py-3 px-4 text-body-md focus:ring-2 focus:ring-secondary/50 @error('nama_toko') border-error @enderror">
                            @error('nama_toko') <span class="text-error text-[11px] font-bold px-1">{{ $message }}</span>@enderror
                        </div>

                        <div class="space-y-2">
                            <label class="text-label-md font-label-md text-on-surface-variant px-1">Nomor Telepon</label>
                            <input type="text" name="nomor_telepon" value="{{ old('nomor_telepon', $setting->nomor_telepon) }}" 
                                class="w-full bg-surface-container-low border border-outline-variant/30 rounded-xl py-3 px-4 text-body-md focus:ring-2 focus:ring-secondary/50 @error('nomor_telepon') border-error @enderror">
                            @error('nomor_telepon') <span class="text-error text-[11px] font-bold px-1">{{ $message }}</span>@enderror
                        </div>

                        <div class="space-y-2 md:col-span-2">
                            <label class="text-label-md font-label-md text-on-surface-variant px-1">Alamat</label>
                            <textarea name="alamat" rows="3" 
                                class="w-full bg-surface-container-low border border-outline-variant/30 rounded-xl py-3 px-4 text-body-md focus:ring-2 focus:ring-secondary/50 @error('alamat') border-error @enderror">{{ old('alamat', $setting->alamat) }}</textarea>
                            @error('alamat') <span class="text-error text-[11px] font-bold px-1">{{ $message }}</span>@enderror
                        </div>

                        <div class="space-y-2 md:col-span-2">
                            <label class="text-label-md font-label-md text-on-surface-variant px-1">Pesan Struk</label>
                            <textarea name="pesan_struk" rows="3" 
                                class="w-full bg-surface-container-low border border-outline-variant/30 rounded-xl py-3 px-4 text-body-md focus:ring-2 focus:ring-secondary/50 @error('pesan_struk') border-error @enderror">{{ old('pesan_struk', $setting->pesan_struk) }}</textarea>
                            @error('pesan_struk') <span class="text-error text-[11px] font-bold px-1">{{ $message }}</span>@enderror
                        </div>

                        <!-- Target Section -->
                        <div class="md:col-span-2 mt-4">
                            <h3 class="text-headline-xs font-headline-xs text-primary px-1 mb-4">Target Saldo Dashboard</h3>
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <div class="space-y-2">
                                    <label class="text-label-md font-label-md text-on-surface-variant px-1">Target Harian (Rp)</label>
                                    <input type="number" name="target_harian" value="{{ old('target_harian', $setting->target_harian) }}" 
                                        class="w-full bg-surface-container-low border border-outline-variant/30 rounded-xl py-3 px-4 text-body-md focus:ring-2 focus:ring-secondary/50 @error('target_harian') border-error @enderror">
                                    @error('target_harian') <span class="text-error text-[11px] font-bold px-1">{{ $message }}</span>@enderror
                                </div>
                                <div class="space-y-2">
                                    <label class="text-label-md font-label-md text-on-surface-variant px-1">Target Mingguan (Rp)</label>
                                    <input type="number" name="target_mingguan" value="{{ old('target_mingguan', $setting->target_mingguan) }}" 
                                        class="w-full bg-surface-container-low border border-outline-variant/30 rounded-xl py-3 px-4 text-body-md focus:ring-2 focus:ring-secondary/50 @error('target_mingguan') border-error @enderror">
                                    @error('target_mingguan') <span class="text-error text-[11px] font-bold px-1">{{ $message }}</span>@enderror
                                </div>
                                <div class="space-y-2">
                                    <label class="text-label-md font-label-md text-on-surface-variant px-1">Target Bulanan (Rp)</label>
                                    <input type="number" name="target_bulanan" value="{{ old('target_bulanan', $setting->target_bulanan) }}" 
                                        class="w-full bg-surface-container-low border border-outline-variant/30 rounded-xl py-3 px-4 text-body-md focus:ring-2 focus:ring-secondary/50 @error('target_bulanan') border-error @enderror">
                                    @error('target_bulanan') <span class="text-error text-[11px] font-bold px-1">{{ $message }}</span>@enderror
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="flex gap-4 pt-4">
                        <button type="submit" 
                            class="w-full px-4 py-4 bg-secondary text-on-secondary rounded-xl font-label-md shadow-lg hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2">
                            <span class="material-symbols-outlined">save</span>
                            Simpan Perubahan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</x-layouts.app>
